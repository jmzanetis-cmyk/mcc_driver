// ============================================================
// MCC Driver — Edge Function: request-payout
// ============================================================
// Handles instant ($0.50 fee, debit only) and standard
// (free, weekly Wednesday) payouts.
// ============================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const INSTANT_FEE = 0.50;
const INSTANT_MIN = 5.00;
const INSTANT_DAILY_LIMIT = 5;

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const authHeader = req.headers.get('Authorization');
    const { data: { user } } = await supabase.auth.getUser(authHeader?.replace('Bearer ', ''));
    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { method, amount } = await req.json();

    // Get driver
    const { data: driver } = await supabase
      .from('drivers')
      .select('id, partner_id')
      .eq('user_id', user.id)
      .single();

    if (!driver) {
      return new Response(JSON.stringify({ error: 'Driver not found' }), {
        status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Partner drivers cannot use instant pay
    if (driver.partner_id && method === 'instant') {
      return new Response(JSON.stringify({ error: 'Partner drivers receive payouts through their company' }), {
        status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Calculate available balance (completed, unpaid assignments)
    const { data: unpaid } = await supabase
      .from('driver_assignments')
      .select('driver_payout_amount')
      .eq('driver_id', driver.id)
      .eq('payout_status', 'pending')
      .eq('status', 'completed');

    const availableBalance = (unpaid || []).reduce(
      (sum, a) => sum + (a.driver_payout_amount || 0), 0
    );

    const payoutAmount = amount || availableBalance;

    if (method === 'instant') {
      if (payoutAmount < INSTANT_MIN) {
        return new Response(JSON.stringify({ error: `Minimum instant payout is $${INSTANT_MIN}` }), {
          status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Check daily limit
      const todayStart = new Date();
      todayStart.setHours(0, 0, 0, 0);
      const { count } = await supabase
        .from('driver_payouts')
        .select('*', { count: 'exact', head: true })
        .eq('driver_id', driver.id)
        .eq('method', 'instant')
        .gte('created_at', todayStart.toISOString());

      if ((count || 0) >= INSTANT_DAILY_LIMIT) {
        return new Response(JSON.stringify({ error: `Daily instant payout limit (${INSTANT_DAILY_LIMIT}) reached` }), {
          status: 429, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      const netPayout = payoutAmount - INSTANT_FEE;

      // Create payout record
      const { data: payout } = await supabase.from('driver_payouts').insert({
        driver_id: driver.id,
        amount: payoutAmount,
        net_payout: netPayout,
        platform_fee: INSTANT_FEE,
        method: 'instant',
        status: 'processing',
        requested_at: new Date().toISOString(),
      }).select().single();

      // TODO: Create Stripe instant payout
      // await stripe.payouts.create({ amount: netPayout * 100, method: 'instant' });

      return new Response(JSON.stringify({
        success: true,
        payoutId: payout?.id,
        netAmount: netPayout,
        arrivalTime: 'Within 30 minutes',
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Standard payout (free, next Wednesday)
    const { data: payout } = await supabase.from('driver_payouts').insert({
      driver_id: driver.id,
      amount: payoutAmount,
      net_payout: payoutAmount,
      platform_fee: 0,
      method: 'standard',
      status: 'scheduled',
      requested_at: new Date().toISOString(),
    }).select().single();

    return new Response(JSON.stringify({
      success: true,
      payoutId: payout?.id,
      netAmount: payoutAmount,
      arrivalTime: 'Next Wednesday',
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
