// ============================================================
// MCC Driver — Edge Function: accept-ride
// ============================================================
// Deploy with: supabase functions deploy accept-ride
//
// Handles: accept, decline, and stage updates.
// Server-side arbitration prevents race conditions.
// ============================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { assignmentId, action = 'accept', rideId } = await req.json();

    if (!assignmentId) {
      return new Response(JSON.stringify({ error: 'assignmentId required' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Fetch current assignment state
    const { data: assignment, error: fetchErr } = await supabase
      .from('driver_assignments')
      .select('*, rides(*)')
      .eq('id', assignmentId)
      .single();

    if (fetchErr || !assignment) {
      return new Response(JSON.stringify({ error: 'Assignment not found' }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Route by action
    if (action === 'accept') {
      // Check still pending and not expired
      if (assignment.status !== 'pending') {
        return new Response(JSON.stringify({ error: 'Assignment already responded to' }), {
          status: 409,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      if (assignment.response_deadline && new Date(assignment.response_deadline) < new Date()) {
        return new Response(JSON.stringify({ error: 'Response deadline passed' }), {
          status: 410,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      // Accept atomically
      await supabase.from('driver_assignments').update({
        status: 'accepted',
        accepted_at: new Date().toISOString(),
      }).eq('id', assignmentId).eq('status', 'pending');

      // Check if all required drivers have accepted
      const ride = assignment.rides;
      const { count } = await supabase
        .from('driver_assignments')
        .select('*', { count: 'exact', head: true })
        .eq('ride_id', ride.id)
        .eq('status', 'accepted');

      // Log the event
      await supabase.from('ride_events').insert({
        ride_id: ride.id,
        event_type: 'driver_accepted',
        actor_id: assignment.driver_id,
        payload: { assignmentId, role: assignment.role },
      });

      return new Response(JSON.stringify({ success: true, accepted: count }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (action === 'decline') {
      await supabase.from('driver_assignments').update({
        status: 'rejected',
        rejected_at: new Date().toISOString(),
      }).eq('id', assignmentId);

      await supabase.from('ride_events').insert({
        ride_id: assignment.ride_id,
        event_type: 'driver_declined',
        actor_id: assignment.driver_id,
        payload: { assignmentId },
      });

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    if (action.startsWith('update_')) {
      const stage = action.replace('update_', '');
      const tsField = `${stage}_at`;

      await supabase.from('driver_assignments').update({
        status: stage,
        [tsField]: new Date().toISOString(),
      }).eq('id', assignmentId);

      // Update ride status
      const statusMap: Record<string, string> = {
        en_route: 'driver_en_route',
        arrived: 'driver_arrived',
        in_progress: 'in_progress',
      };

      if (statusMap[stage] && rideId) {
        await supabase.from('rides').update({
          status: statusMap[stage],
        }).eq('id', rideId);
      }

      await supabase.from('ride_events').insert({
        ride_id: assignment.ride_id,
        event_type: `stage_${stage}`,
        actor_id: assignment.driver_id,
        payload: { assignmentId },
      });

      return new Response(JSON.stringify({ success: true }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    return new Response(JSON.stringify({ error: `Unknown action: ${action}` }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
