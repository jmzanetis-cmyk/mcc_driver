// ============================================================
// MCC Driver — Edge Function: cancel-ride
// ============================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const authHeader = req.headers.get('Authorization');
    const { data: { user } } = await supabase.auth.getUser(authHeader?.replace('Bearer ', ''));
    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { rideId, reason } = await req.json();

    const { data: ride } = await supabase
      .from('rides')
      .select('status, estimated_fare')
      .eq('id', rideId)
      .single();

    if (!ride) {
      return new Response(JSON.stringify({ error: 'Ride not found' }), {
        status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Check cancellable
    const cancellable = ['requested', 'searching', 'driver_assigned', 'driver_accepted', 'driver_en_route', 'driver_arrived'];
    if (!cancellable.includes(ride.status)) {
      return new Response(JSON.stringify({ error: 'Ride cannot be cancelled in current state' }), {
        status: 409, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Cancel ride
    await supabase.from('rides').update({
      status: 'cancelled_driver',
      cancellation_reason: reason,
      cancelled_at: new Date().toISOString(),
    }).eq('id', rideId);

    // Cancel all active assignments
    await supabase.from('driver_assignments').update({
      status: 'cancelled',
    }).eq('ride_id', rideId).in('status', ['pending', 'accepted', 'en_route', 'arrived']);

    await supabase.from('ride_events').insert({
      ride_id: rideId,
      event_type: 'ride_cancelled_by_driver',
      actor_id: user.id,
      payload: { reason },
    });

    return new Response(JSON.stringify({ success: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
