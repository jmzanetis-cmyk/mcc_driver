// ============================================================
// MCC Driver — Edge Function: complete-ride
// ============================================================
// Handles fare recalculation, Stripe payment capture, and
// 85/15 revenue split atomically.
// ============================================================

import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { headers: corsHeaders });

  try {
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    );

    const { rideId, assignmentId, actualDistanceMiles } = await req.json();

    const { data: ride } = await supabase
      .from('rides')
      .select('*')
      .eq('id', rideId)
      .single();

    if (!ride || ride.status !== 'in_progress') {
      return new Response(JSON.stringify({ error: 'Ride not in progress' }), {
        status: 409, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    // Recalculate fare with actual distance
    // Using the pricing stored on the ride record
    const baseRate = ride.base_rate || 10;
    const perMileRate = ride.per_mile_rate || 1.5;
    const minFare = ride.minimum_fare || 12;
    const platformFeePct = ride.mcc_platform_fee_pct || 15;

    const rawFare = baseRate + (actualDistanceMiles * perMileRate);
    const finalFare = Math.max(rawFare, minFare);
    const mccFee = finalFare * (platformFeePct / 100);
    const partnerPayout = finalFare - mccFee;

    // Update ride
    await supabase.from('rides').update({
      status: 'completed',
      actual_distance_miles: actualDistanceMiles,
      actual_fare: Math.round(finalFare * 100) / 100,
      mcc_platform_fee_amount: Math.round(mccFee * 100) / 100,
      partner_payout_amount: Math.round(partnerPayout * 100) / 100,
      completed_at: new Date().toISOString(),
    }).eq('id', rideId);

    // Update assignment
    await supabase.from('driver_assignments').update({
      status: 'completed',
      completed_at: new Date().toISOString(),
      driver_payout_amount: Math.round(partnerPayout * 100) / 100,
      payout_status: 'pending',
    }).eq('id', assignmentId);

    // Log event
    await supabase.from('ride_events').insert({
      ride_id: rideId,
      event_type: 'ride_completed',
      payload: { actualDistanceMiles, finalFare, partnerPayout, mccFee },
    });

    // TODO: Capture Stripe payment intent and create transfer
    // await stripe.paymentIntents.capture(ride.stripe_payment_intent_id);
    // await stripe.transfers.create({ amount, destination: partnerStripeAccountId });

    return new Response(JSON.stringify({
      success: true,
      finalFare: Math.round(finalFare * 100) / 100,
      driverPayout: Math.round(partnerPayout * 100) / 100,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
