import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import { initSentry } from '@/services/telemetry/sentry';

// Initialize error tracking before anything else
initSentry();

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
